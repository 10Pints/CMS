﻿namespace CMS.Maui;
   public partial class App : Application
   {
      private readonly MainPage _mainPage;

      public App(MainPage mainPage)
      {
         InitializeComponent();
         NavigationPage navigationPage  = new NavigationPage(mainPage);
         _mainPage = mainPage ?? throw new ArgumentNullException(nameof(mainPage));
   }

      protected override Window CreateWindow(IActivationState? activationState)
      {
         return new Window(new AppShell());
      }
   }
